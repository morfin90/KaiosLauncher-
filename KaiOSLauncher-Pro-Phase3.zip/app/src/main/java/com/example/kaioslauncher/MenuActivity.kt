package com.example.kaioslauncher

class MenuActivity { /* activity logic here */ }