package com.example.kaioslauncher

data class AppItem(val iconResId: Int, val label: String)