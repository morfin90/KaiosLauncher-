package com.example.kaioslauncher

class AppAdapter { /* adapter logic here */ }